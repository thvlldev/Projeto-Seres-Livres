// Script de filtragem melhorado
document.addEventListener('DOMContentLoaded', function () {
    const btnsFiltro = document.querySelectorAll('.btn-filtro');
    const animais = document.querySelectorAll('.animal-card');
    const mensagemVazia = document.getElementById('mensagem-vazia');
    const gridAnimais = document.getElementById('grid-animais');

    btnsFiltro.forEach(btn => {
        btn.addEventListener('click', function () {
            const filtro = this.getAttribute('data-filter');

            // Remove active de todos os botões
            btnsFiltro.forEach(b => b.classList.remove('active'));
            // Adiciona active no botão clicado
            this.classList.add('active');

            let count = 0;

            // Filtra os animais
            animais.forEach(animal => {
                const especie = animal.getAttribute('data-especie');

                if (filtro === 'todos' || especie === filtro) {
                    animal.style.display = 'block';
                    count++;
                } else {
                    animal.style.display = 'none';
                }
            });

            // Mostra mensagem se não houver animais
            if (count === 0) {
                mensagemVazia.style.display = 'block';
                gridAnimais.style.display = 'none';
            } else {
                mensagemVazia.style.display = 'none';
                gridAnimais.style.display = 'flex';
            }
        });
    });
});